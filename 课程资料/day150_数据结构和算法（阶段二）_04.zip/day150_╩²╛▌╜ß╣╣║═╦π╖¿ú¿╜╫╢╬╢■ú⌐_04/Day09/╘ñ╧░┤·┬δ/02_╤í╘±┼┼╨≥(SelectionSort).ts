import { swap, testSort } from "./utils"
import { measureSort } from 'hy-algokit'

export default function selectionSort(arr: number[]): number[] {
  const n = arr.length
  for (let i = 0; i < n - 1; i++) {
    // 记录未排序部分的最小值的索引
    let minIndex = i
    for (let j = i + 1; j < n; j++) {
      if (arr[j] < arr[minIndex]) {
        minIndex = j
      }
    }

    if (i !== minIndex) {
      swap(arr, i, minIndex)
    }
  }
  return arr
}

// testSort(selectionSort)
// measureSort(selectionSort)
