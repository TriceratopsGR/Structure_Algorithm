function lengthOfLIS(nums: number[]): number {
  const tails: number[] = []

  for (const num of nums) {
    let left = 0
    let right = tails.length - 1

    while (left <= right) {
      const mid = Math.floor((left + right) / 2)
      if (num <= tails[mid]) {
        right = mid - 1
      } else {
        left = mid + 1
      }
    }

    if (left === tails.length) {
      tails.push(num)
    } else {
      tails[left] = num
    }
  }
  return tails.length
}