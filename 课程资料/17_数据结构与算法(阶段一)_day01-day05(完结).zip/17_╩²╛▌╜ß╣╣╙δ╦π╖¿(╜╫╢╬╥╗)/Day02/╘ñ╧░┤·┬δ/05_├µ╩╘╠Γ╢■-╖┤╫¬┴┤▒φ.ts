import ListNode from "./ListNode"

function reverseList(head: ListNode | null): ListNode | null {
  if (head === null) return null
  if (head.next === null) return head

  const newHead = reverseList(head.next)

  head.next.next = head
  head.next = null

  return newHead
};

const node1 = new ListNode(111)
node1.next = new ListNode(222)
node1.next.next = new ListNode(333)
node1.next.next.next = new ListNode(444)
node1.next.next.next.next = new ListNode(555)

let newNode = reverseList(node1)
while (newNode) {
  console.log(newNode?.val)
  newNode = newNode.next
}
