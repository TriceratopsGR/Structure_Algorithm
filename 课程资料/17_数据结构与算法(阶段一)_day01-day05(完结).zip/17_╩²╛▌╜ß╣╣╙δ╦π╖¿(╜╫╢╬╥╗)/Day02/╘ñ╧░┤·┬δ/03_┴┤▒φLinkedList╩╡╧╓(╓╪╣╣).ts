class Node<T> {
  constructor(
    public value: T, 
    public next: Node<T> | null = null
  ) {}
}


class LinkedList<T> {
  private head: Node<T> | null = null
  private size: number = 0

  // 实现方法
  append(value: T) {
    const newNode = new Node(value)
    if (!this.head) {
      this.head = newNode
    } else {
      let current = this.head
      while (current.next) {
        current = current.next
      }
      current.next = newNode
    }
    this.size++
  }

  // 任意位置插入元素
  insert(value: T, position: number): boolean {
    if (position < 0 || position > this.size) return false

    // 创建新节点
    const newNode = new Node(value)
    if (position === 0) {
      newNode.next = this.head
      this.head = newNode
    } else {
      const previous = this.getNode(position - 1)
      newNode.next = previous!.next
      previous!.next = newNode
    }

    this.size++
    return true
  }

  // 删除方法
  removeAt(position: number): T | null {
    if (position < 0 || position >= this.size) return null
    let current = this.head
    if (position === 0) {
      this.head = this.head?.next ?? null
    } else {
      const previous = this.getNode(position - 1)
      current = previous!.next
      previous!.next = current?.next ?? null
    }
    this.size--
    return current?.value ?? null
  }

  // 根据索引获取元素
  get(position: number): T | null {
    if (position < 0 || position >= this.size) return null
    const current = this.getNode(position)
    return current?.value ?? null
  }

  // 更新元素方法
  update(value: T, position: number) {
    if (position < 0 || position >= this.size) return
    const current = this.getNode(position)
    if (current) {
      current.value = value
    }
  }

  // 获取元素的位置
  indexOf(value: T): number {
    let index = 0
    let current = this.head
    while (current) {
      if (current.value === value) return index
      index++
      current = current.next
    }
    return -1
  }

  // 根据元素删除
  remove(value: T): T | null {
    const index = this.indexOf(value)
    return this.removeAt(index)
  }

  isEmpty() {
    return this.size === 0
  }

  // 遍历链表
  traverse() {
    const values: T[] = []
    let current = this.head
    while (current) {
      values.push(current.value)
      current = current.next
    }
    console.log(values.join('->'))
  }

  // 私有方法
  private getNode(position: number): Node<T> | null {
    let index = 0
    let current = this.head
    while (index++ < position && current) {
      current = current.next
    }
    return current
  }
}

const linkedList = new LinkedList<string>()
linkedList.append("aaa")
linkedList.append("bbb")
linkedList.append("ccc")

linkedList.insert("abc", 2)
linkedList.insert("cba", 1)
linkedList.insert("nba", 0)
linkedList.insert("mba", 6)

linkedList.traverse()

linkedList.removeAt(3)
linkedList.removeAt(0)
linkedList.removeAt(4)
linkedList.traverse()

console.log(linkedList.get(0))
console.log(linkedList.get(2))
console.log(linkedList.get(3))

console.log(linkedList.indexOf('ccc'))
console.log(linkedList.indexOf('abc'))
console.log(linkedList.indexOf('aaa'))

export {}
