import Queue from "./04_实现Queue";

function leftRemaining(n: number, m: number) {
  // 1.创建队列
  const queue = new Queue<number>()
  for (let i = 0; i < n; i++) {
    queue.enqueue(i)
  }

  // 2.开始淘汰人
  while (n > 1) {
    for (let i = 1; i < m; i++) {
      queue.enqueue(queue.dequeue()!)
    }
    queue.dequeue()
    n--
  }

  return queue.dequeue()!
}

console.log(leftRemaining(5, 3))
console.log(leftRemaining(10, 17))

export {}

export {}
