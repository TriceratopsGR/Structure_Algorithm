import { btPrint } from 'hy-algokit'

class Node<T=number>{
  value: T
  left: Node<T> | null
  right: Node<T> | null

  constructor(value: T) {
    this.value = value
    this.left = null
    this.right = null
  }
}

class BSTree<T = number> {
  root: Node<T> | null = null

  // 二叉搜索树的其他方法
  // 插入节点
  insert(value: T) {
    // 创建新的节点
    const newNode = new Node(value)

    // 判断是否有根节点
    if (!this.root) {
      this.root = newNode
    } else {
      this.insertNode(this.root, newNode)
    }
  }
  private insertNode(node: Node<T>, newNode: Node<T>) {
    if (newNode.value < node.value) { // 向左子树插入
      if (node.left === null) { // 左子树上没有内容
        node.left = newNode
      } else {
        this.insertNode(node.left, newNode)
      }
    } else { // 向右子树插入
      if (node.right === null) {
        node.right = newNode
      } else {
        this.insertNode(node.right, newNode)
      }
    }
  }

  // 树的遍历
  // 先序遍历
  preOrderTraverse() {
    this.preOrderTraverseNode(this.root)
  }
  private preOrderTraverseNode(node: Node<T> | null) {
    if (node) {
      console.log(node.value)
      this.preOrderTraverseNode(node.left)
      this.preOrderTraverseNode(node.right)
    }
  }

  preOrderTraversalNoRecursion() {
    let stack: Node<T>[] = [];
    let current: Node<T> | null = this.root;

    while (current !== null || stack.length !== 0) {
      while (current !== null) {
        console.log(current.value);
        stack.push(current);
        current = current.left;
      }

      current = stack.pop()!;
      current = current.right;
    }
  }

  // 中序遍历
  inOrderTraverse() {
    this.inOrderTraverseNode(this.root)
  }
  private inOrderTraverseNode(node: Node<T> | null) {
    if (node) {
      this.inOrderTraverseNode(node.left)
      console.log(node.value)
      this.inOrderTraverseNode(node.right)
    }
  }

  inOrderTraverseNonRecursive() {
    let stack: Node<T>[] = [];
    let current: Node<T> | null = this.root;

    while (current !== null || stack.length !== 0) {
      while (current !== null) {
        stack.push(current);
        current = current.left;
      }

      current = stack.pop()!;
      console.log(current.value);
      current = current.right;
    }
  }

  // 后序遍历
  postOrderTraverse() {
    this.postOrderTraverseNode(this.root)
  }
  private postOrderTraverseNode(node: Node<T> | null) {
    if (node) {
      this.postOrderTraverseNode(node.left)
      this.postOrderTraverseNode(node.right)
      console.log(node.value)
    }
  }

  postOrderTraversalNoRecursion() {
    let stack: Node<T>[] = [];
    let current: Node<T> | null = this.root;
    let lastVisitedNode: Node<T> | null = null;

    while (current !== null || stack.length !== 0) {
      while (current !== null) {
        stack.push(current);
        current = current.left;
      }

      current = stack[stack.length - 1];
      if (current.right === null || current.right === lastVisitedNode) {
        console.log(current.value);
        lastVisitedNode = current;
        stack.pop();
        current = null;
      } else {
        current = current.right;
      }
    }
  }

  // 层序遍历
  levelOrderTraversal() {
    // 没有根节点, 直接返回
    if (!this.root) return

    // 创建一个队列
    const queue: Node<T>[] = []
    queue.push(this.root)

    while (queue.length !== 0) {
      const current = queue.shift()!
      console.log(current.value)

      if (current.left !== null) {
        queue.push(current.left)
      }

      if (current.right !== null) {
        queue.push(current.right)
      }
    }
  }


  // 获取最值
  // 获取最小值
  getMinValue(): T | null {
    let current = this.root
    while (current && current.left) {
      current = current.left
    }
    return current?.value ?? null
  }
  // 获取最大值
  getMaxValue(): T | null {
    let current = this.root
    while (current && current.right) {
      current = current.right
    }
    return current?.value ?? null
  }

  // 搜索特定的值
  search(value: T): boolean {
    return this.searchNode(this.root, value)
  }
  private searchNode(node: Node<T> | null, value: T): boolean {
    // 1.如果节点为null, 那么就直接推出递归
    if (node === null) return false

    // 2.判断node节点的value和传入的value的大小
    if (node.value > value) { // 在左边继续查找
      return this.searchNode(node.left, value)
    } else if (node.value < value) { // 在右边继续查找
      return this.searchNode(node.right, value)
    } else {
      return true
    }
  }

  searchNoRecursion(value: T) {
    let current = this.root
    while (current) {
      if (current.value > value) {
        current = current.left
      } else if (current.value < value) {
        current = current.right
      } else {
        return true
      }
    }
    return false
  }

  // 删除操作
  private getSuccessor(delNode: Node<T>): Node<T> {
    // 1.保存临时节点变量
    let successor = delNode
    let successorParent = delNode
    let current = delNode.right

    // 2.寻找后继节点
    while (current !== null) {
      successorParent = successor
      successor = current
      current = current.left
    }

    // 3.如果删除后继节点还有右节点, 那么还需要如下操作
    if (successor !== delNode.right) {
      successorParent.left = successor.right
      successor.right = delNode.right
    }

    return successor
  }

  remove(value: T): boolean {
    if (!this.root) return false

    // 1.查找到该节点的位置(如果没有直接返回)
    let current: Node<T> | null = this.root // 当前节点
    let parent: Node<T> | null = null // 父节点
    let isLeft = true // 是否是父节点左子节点

    while (current.value !== value) {
      parent = current
      if (value < current.value) {
        isLeft = true
        current = current.left
      } else {
        isLeft = false
        current = current.right
      }

      if (current === null) return false
    }

    // 2.查找到value节点的位置
    // 2.1. 判断左右节点如果都为空
    if (current.left === null && current.right === null) {
      if (!parent) {
        this.root = null
      } else if (isLeft) {
        parent.left = null
      } else {
        parent.right = null
      }
    } else if (current.right === null) { //有左节点
      if (!parent) {
        this.root = current.left
      } else if (isLeft) {
        parent.left = current.left
      } else {
        parent.right = current.left
      }
    } else if (current.left === null) { //有右节点
      if (!parent) {
        this.root = current.right
      } else if (isLeft) {
        parent.left = current.right
      } else {
        parent.right = current.right
      }
    } else {
      const successor = this.getSuccessor(current)
      if (!parent) {
        this.root = successor
      } else if (isLeft) {
        parent.left = successor
      } else {
        parent.right = successor
      }
      // 将删除节点的左子树复制给successor
      successor.left = current.left
    }


    return true
  }
}

const bst = new BSTree()
bst.insert(11)
bst.insert(7)
bst.insert(15)
bst.insert(5)
bst.insert(3)
bst.insert(9)
bst.insert(8)
bst.insert(10)
bst.insert(13)
bst.insert(12)
bst.insert(14)
bst.insert(20)
bst.insert(18)
bst.insert(25)
bst.insert(6)
bst.insert(19)

btPrint(bst.root)

// console.log(bst.search(25))
// console.log(bst.search(13))
// console.log(bst.search(30))

// bst.remove(10)
// bst.remove(8)
// bst.remove(5)
// bst.remove(15)
bst.remove(11)
btPrint(bst.root)

export {}
