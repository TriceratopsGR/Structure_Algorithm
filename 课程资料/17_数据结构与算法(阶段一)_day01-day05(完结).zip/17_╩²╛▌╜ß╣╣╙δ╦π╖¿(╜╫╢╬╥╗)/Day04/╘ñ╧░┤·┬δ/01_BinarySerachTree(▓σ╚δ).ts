// import { print, PrintableNode } from "./print2"
import { btPrint } from 'hy-algokit'

class Node<T=number>{
  value: T
  left: Node<T> | null
  right: Node<T> | null

  constructor(value: T) {
    this.value = value
    this.left = null
    this.right = null
  }
}

class BSTree<T = number> {
  root: Node<T> | null = null

  // 二叉搜索树的其他方法
  // 插入节点
  insert(value: T) {
    // 创建新的节点
    const newNode = new Node(value)

    // 判断是否有根节点
    if (!this.root) {
      this.root = newNode
    } else {
      this.insertNode(this.root, newNode)
    }
  }
  private insertNode(node: Node<T>, newNode: Node<T>) {
    if (newNode.value < node.value) { // 向左子树插入
      if (node.left === null) { // 左子树上没有内容
        node.left = newNode
      } else {
        this.insertNode(node.left, newNode)
      }
    } else { // 向右子树插入
      if (node.right === null) {
        node.right = newNode
      } else {
        this.insertNode(node.right, newNode)
      }
    }
  }

  // 树的遍历
  // 先序遍历
  preOrderTraverse() {
    this.preOrderTraverseNode(this.root)
  }
  private preOrderTraverseNode(node: Node<T> | null) {
    if (node) {
      console.log(node.value)
      this.preOrderTraverseNode(node.left)
      this.preOrderTraverseNode(node.right)
    }
  }
}

const bst = new BSTree()
bst.insert(11)
bst.insert(7)
bst.insert(15)
bst.insert(5)
bst.insert(3)
bst.insert(9)
bst.insert(8)
bst.insert(10)
bst.insert(13)
bst.insert(12)
bst.insert(14)
bst.insert(20)
bst.insert(18)
bst.insert(25)
// bst.insert(6)

// btPrint(bst.root)

bst.preOrderTraverse()

export {}
