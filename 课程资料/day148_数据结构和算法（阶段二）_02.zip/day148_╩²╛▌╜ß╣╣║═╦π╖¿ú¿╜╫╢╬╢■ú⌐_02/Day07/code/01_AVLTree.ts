import BSTree from "./11_二叉搜索树BSTree(删除-代码重构)";
import AVLTreeNode from "./AVLTreeNode";

class AVLTree<T> extends BSTree<T> {
  rebalance(grand: AVLTreeNode<T>) {
    // 1.获取到父节点parent/current
    const parent = grand.higherChild
    const current = parent?.higherChild

    let resultNode: AVLTreeNode<T> | null = null
    // 2.判断属于哪一种情况: LL/RR/LR/RL
    if (parent?.isLeft) { // L
      if (current?.isLeft) { // L
        resultNode = grand.rotateRight()
      } else { // LR
        parent.rotateLeft()
        resultNode = grand.rotateRight()
      }
    } else { // R
      if (current?.isLeft) { // RL
        parent?.rotateRight()
        resultNode = grand.rotateLeft()
      } else { // RR
        resultNode = grand.rotateLeft()
      }
    }
    if (resultNode.parent === null) {
      this.root = resultNode
    }
  }

  protected createNode(value: T): AVLTreeNode<T> {
    return new AVLTreeNode(value)
  }

  protected checkBalance(currentNode: AVLTreeNode<T>): void {
    let current = currentNode.parent
    while (current) {
      // 找到不平衡的节点后, 就让它恢复平衡
      if (!current.isBalanced) {
        this.rebalance(current)
      }
      current = current.parent
    }
  }
}

const avltree = new AVLTree<number>()
// avltree.insert(100)
// avltree.insert(50)
// avltree.insert(150)
// avltree.insert(25)
// avltree.insert(75)
// avltree.print()

// avltree.insert(12)
// avltree.print()

// // RR
// avltree.insert(160)
// avltree.insert(165)
// avltree.print()

// // RL
// avltree.insert(140)
// avltree.print()

// // LR
// avltree.insert(8)
// avltree.insert(11)
// avltree.insert(9)
// avltree.print()

// for (let i = 0; i < 20; i++) {
//   const num = Math.ceil(Math.random() * 200)
//   avltree.insert(num)
// }

avltree.insert(17)
avltree.insert(15)
avltree.insert(25)
avltree.insert(22)
avltree.insert(27)
avltree.insert(30)

avltree.print()


