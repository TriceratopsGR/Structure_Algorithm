class Graph<T> {
  // 属性
  verteces: T[] = []
  adjList: Map<T, T[]> = new Map()

  // 方法
  addVertex(v: T) {
    this.verteces.push(v)
    this.adjList.set(v, [])
  }

  addEdge(v: T, w: T) {
    this.adjList.get(v)?.push(w)
    this.adjList.get(w)?.push(v)
  }

  bfs() {
    if (this.verteces.length === 0) return
    const visited = new Set<T>()
    visited.add(this.verteces[0])
    const queue = [this.verteces[0]]

    while (queue.length) {
      const vertex = queue.shift()!
      console.log(vertex)

      const neighbors = this.adjList.get(vertex)
      if (!neighbors) continue
      for (const neighbor of neighbors) {
        if (!visited.has(neighbor)) {
          visited.add(neighbor)
          queue.push(neighbor)
        }
      }
    }
  }

  dfs() {
    if (this.verteces.length === 0) return
    const visited = new Set<T>()
    visited.add(this.verteces[0])
    const stack = [this.verteces[0]]

    while (stack.length) {
      const vertex = stack.pop()!
      console.log(vertex)

      const neighbors = this.adjList.get(vertex)
      if (!neighbors) continue
      for (let i = neighbors.length - 1; i >= 0; i--) {
        const neighbor = neighbors[i]
        if (!visited.has(neighbor)) {
          stack.push(neighbor)
          visited.add(neighbor)
        }
      }
    }
  }

  printEdges() {
    console.log("Edges:")
    this.verteces.forEach(vertex => {
      console.log(`${vertex} -> ${this.adjList.get(vertex)?.join(" ")}`)
    })
  }
}

// 添加A~I的顶点
const graph = new Graph<string>()
for (let i = 65; i < 74; i++) {
  graph.addVertex(String.fromCharCode(i))
}

graph.addEdge('A', 'B');
graph.addEdge('A', 'C');
graph.addEdge('A', 'D');
graph.addEdge('C', 'D');
graph.addEdge('C', 'G');
graph.addEdge('D', 'G');
graph.addEdge('D', 'H');
graph.addEdge('B', 'E');
graph.addEdge('B', 'F');
graph.addEdge('E', 'I');

graph.printEdges()

// graph.bfs()
graph.dfs()
