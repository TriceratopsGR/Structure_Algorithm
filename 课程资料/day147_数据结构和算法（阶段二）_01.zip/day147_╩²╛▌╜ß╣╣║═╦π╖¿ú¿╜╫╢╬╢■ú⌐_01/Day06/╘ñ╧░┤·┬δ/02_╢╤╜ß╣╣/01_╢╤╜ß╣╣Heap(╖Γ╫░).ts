class Heap<T> {
  private data: T[] = []
  private size: number = 0

  private swap(i: number, j: number) {
    const temp = this.data[i]
    this.data[i] = this.data[j]
    this.data[j] = temp
  }

  /** 插入方法 */
  insert(value: T) {
    this.data.push(value)
    this.size++
    this.heapify_up()
  }

  private heapify_up() {
    let index = this.size - 1
    while (index > 0) {
      let parentIndex = Math.floor((index - 1) / 2)
      if (this.data[index] >= this.data[parentIndex]) {
        break
      }
      this.swap(index, parentIndex)
      index = parentIndex
    }
  }
}

export {}
