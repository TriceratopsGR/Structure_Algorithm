import { swap, testSort } from "./utils"
import { measureSort } from 'hy-algokit'

export default function quickSort(arr: number[]): number[] {
  function partition(left: number, right: number) {
    // 如果左右指针相当, 那么排序已经完成, 直接返回
    if (left >= right) return

    // 1.选择最后一个元素作为基准元素
    const mid = left + Math.floor((left + right) / 2)
    if (mid > left && mid < right) {
      if (arr[left] > arr[right]) swap(arr, left, right)
      if (arr[mid] > arr[right]) swap(arr, mid, right)
      if (arr[left] > arr[mid]) swap(arr, left, mid)
      swap(arr, mid, right)
    }
    
    const pivot = arr[right]

    // 2.初始化左右指针
    let i = left
    let j = right - 1
    while (i <= j) {
      // 左指针向右移动, 直接找到一个大于或者等于基准元素的值
      while (arr[i] < pivot) {
        i++
      }
      // 右指针向左移动, 直接找到一个小于或者等于基准元素的值
      while (arr[j] > pivot) {
        j--
      }

      if (i <= j) {
        swap(arr, i, j)
        i++
        j--
      }
    }

    // 将轴点元素和放在总监位置
    swap(arr, i, right)

    // 递归的对左右两个子数组进行快速排序
    partition(left, j)
    partition(i + 1, right)
  }

  partition(0, arr.length - 1)
  return arr
}

// testSort(quickSort)
// measureSort(quickSort)

const arr = [5,1,1,2,0,0]
quickSort(arr)
console.log(arr)
