import ArrayQueue from "../02_队列结构Queue/01_实现队列结构Queue";

class Deque<T> extends ArrayQueue<T> {
  addFront(value: T) {
    this.data.unshift(value)
  }

  removeBack(): T | undefined {
    return this.data.pop()
  }
}

const deque = new Deque<number>()
deque.enqueue(10)
deque.enqueue(20)
deque.addFront(30)

console.log(deque.peek())
while (!deque.isEmpty()) {
  console.log(deque.dequeue())
}

