import ArrayQueue from '../02_队列结构Queue/01_实现队列结构Queue'
import IQueue from '../02_队列结构Queue/IQueue'
import Heap from '../08_二叉堆(Heap)/04_堆结构Heap(原地建堆)'
import Node from '../types2/Node'

class PriorityNode<T> extends Node<T> {
  priority: number
  constructor(value: T, priority: number) {
    super(value)
    this.priority = priority
  }

  valueOf() {
    return this.priority
  }
}

class PriorityQueue<T> {
  private heap: Heap<PriorityNode<T>> = new Heap()

  enqueue(element: T, priority: number): void {
    const node = new PriorityNode(element, priority)
    this.heap.insert(node)
  }

  dequeue(): T | undefined {
    return this.heap.delete()?.value
  }

  peek(): T | undefined {
    return this.heap.peek()?.value
  }

  isEmpty() {
    return this.heap.isEmpty()
  }

  size() {
    return this.heap.length
  }
}

const priorityQueue = new PriorityQueue<string>()
priorityQueue.enqueue("abc", 100)
priorityQueue.enqueue("cba", 50)
priorityQueue.enqueue("nba", 120)
priorityQueue.enqueue("mba", 200)

while (!priorityQueue.isEmpty()) {
  console.log(priorityQueue.dequeue())
}
