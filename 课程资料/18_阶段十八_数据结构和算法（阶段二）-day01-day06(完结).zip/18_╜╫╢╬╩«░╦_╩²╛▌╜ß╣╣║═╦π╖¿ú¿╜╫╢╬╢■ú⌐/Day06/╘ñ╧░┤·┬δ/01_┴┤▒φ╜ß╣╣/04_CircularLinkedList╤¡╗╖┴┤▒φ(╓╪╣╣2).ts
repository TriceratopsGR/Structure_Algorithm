import LinkedList from "../03_链表结构LinkedList/16_实现LinkedList(接口设计)";
import { LinkedNode } from '../types/LinkedNode'

class CircularLinkedList<T> extends LinkedList<T> {
  // 重写一些方法
  append(value: T): void {
    super.append(value)
    this.lastNode!.next = this.head
  }

  // 遍历方法
  // traverse(): void {
  //   if (!this.head) return

  //   const values: T[] = []
  //   let current: LinkedNode<T> | null = this.head
  //   while (current) {
  //     values.push(current.value)
  //     if (!this.isLastNode(current)) {
  //       current = current.next
  //     } else {
  //       current = null
  //     }
  //   }
  //   values.push(this.head.value)
  //   console.log(values.join("->"))
  // }

  // 插入到任意的位置
  insert(value: T, position: number): boolean {
    const lastNode = this.lastNode
    const isSuccess = super.insert(value, position)
    if (isSuccess && position === 0 && lastNode) {
      lastNode.next = this.head
    }
    return isSuccess
  }

  // 根据位置删除元素
  removeAt(position: number): T | null {
    const lastNode = this.lastNode
    const value = super.removeAt(position)
    if (value && position === 0 && lastNode) {
      lastNode.next = this.head
    }
    if (this.length === 0) {
      this.head = null
    }
    return value
  }
}

const linkedList = new CircularLinkedList<string>()
console.log('------------ 测试append ------------')
linkedList.append("aaa")
linkedList.append("bbb")
linkedList.append("ccc")
linkedList.append("ddd")
linkedList.traverse()

console.log('------------ 测试insert ------------')
linkedList.insert("abc", 0)
linkedList.traverse()
linkedList.insert("cba", 2)
linkedList.insert("nba", 6)
linkedList.traverse()

// // 测试删除节点
// console.log('------------ 测试removeAt ------------')
linkedList.removeAt(0)
linkedList.removeAt(0)
linkedList.traverse()

console.log(linkedList.removeAt(2))
linkedList.traverse()
console.log(linkedList.removeAt(3))
linkedList.traverse()

// console.log('------------ 测试get ------------')
console.log(linkedList.get(0))
console.log(linkedList.get(1))
console.log(linkedList.get(2))

// console.log('------------ 测试update ------------')
linkedList.update("why", 1)
linkedList.update("kobe", 2)
linkedList.traverse()

// console.log('------------ 测试indexOf ------------')
console.log(linkedList.indexOf("cba"))
console.log(linkedList.indexOf("why"))
console.log(linkedList.indexOf("kobe"))
console.log(linkedList.indexOf("james"))

console.log('------------ 测试remove ------------')
linkedList.remove("why")
linkedList.remove("cba")
linkedList.remove("kobe")
linkedList.traverse()
console.log(linkedList.isEmpty())
