import LinkedList from "../03_链表结构LinkedList/16_实现LinkedList(接口设计)";
import { DoublyLinkedNode } from "../types/LinkedNode";

class DoublyLinkedList<T> extends LinkedList<T> {
  protected head: DoublyLinkedNode<T> | null = null
  protected tail: DoublyLinkedNode<T> | null = null

  postTraverse() {
    let current = this.tail
    const values: T[] = []
    while (current) {
      values.push(current.value)
      current = current.prev
    }
    console.log(values.join('->'))
  }

  /** 添加节点 */
  append(value: T): void {
    const newNode = new DoublyLinkedNode(value)

    if (this.head === null) {
      this.head = newNode
      this.tail = newNode
    } else {
      this.tail!.next = newNode
      newNode.prev = this.tail
      this.tail = newNode
    }

    this.length++
  }

  prepend(value: T): void {
    const newNode = new DoublyLinkedNode(value)

    if (!this.head) {
      this.tail = newNode
      this.head = newNode
    } else {
      newNode.next = this.head
      this.head.prev = newNode
      this.head = newNode
    }

    this.length++
  }

  insert(value: T, position: number): boolean {
    if (position < 0 && position > this.length) return false
    if (position === 0) {
      this.prepend(value)
    } else if (position === this.length) {
      this.append(value)
    } else {
      const newNode = new DoublyLinkedNode(value)
      const current = this.getNode(position) as DoublyLinkedNode<T>
      current.prev!.next = newNode
      newNode.prev = current.prev
      current.prev = newNode
      newNode.next = current

      this.length++ // 注意length++的位置
    }
    return true
  }

  /** 移除节点 */
  removeAt(position: number): T | null {
    if (position < 0 || position >= this.length) return null

    let current = this.head
    if (position === 0) {
      if (this.length === 1) {
        this.head = null
        this.tail = null
      } else {
        this.head = this.head!.next
        this.head!.prev = null
      }
    } else if (position === this.length - 1) {
      current = this.tail
      this.tail = this.tail!.prev
      this.tail!.next = null
    } else {
      current = this.getNode(position) as DoublyLinkedNode<T>
      current.prev!.next = current.next
      current.next!.prev = current.prev
    }

    this.length--
    return current?.value ?? null
  }
}

const dLinkedList = new DoublyLinkedList<string>()
dLinkedList.append("aaa")
dLinkedList.append("bbb")
dLinkedList.append("ccc")
dLinkedList.append("ddd")
// dLinkedList.traverse()

dLinkedList.prepend("abc")
dLinkedList.prepend("cba")
dLinkedList.prepend("nba")
dLinkedList.traverse()

// dLinkedList.postTraverse()

dLinkedList.insert("why", 0)
dLinkedList.insert("kobe", 8)
dLinkedList.insert("james", 5)

dLinkedList.traverse()
// dLinkedList.postTraverse()

dLinkedList.removeAt(0)
dLinkedList.removeAt(8)
dLinkedList.removeAt(4)
dLinkedList.traverse()

console.log(dLinkedList.indexOf("aaa"))

