class Heap<T> {
  private data: T[] = []
  private size: number = 0

  constructor(arr: T[] = []) {
    if (arr.length) {
      this.build_heap(arr)
    }
  }

  private swap(i: number, j: number) {
    const temp = this.data[i]
    this.data[i] = this.data[j]
    this.data[j] = temp
  }

  traverse() {
    console.log(this.data.join(" "))
  }

  /** 插入方法 */
  insert(value: T) {
    this.data.push(value)
    this.size++
    this.heapify_up()
  }

  private heapify_up() {
    let index = this.size - 1
    while (index > 0) {
      let parentIndex = Math.floor((index - 1) / 2)
      if (this.data[index] <= this.data[parentIndex]) {
        break
      }
      this.swap(index, parentIndex)
      index = parentIndex
    }
  }

  /** 提取操作 */
  delete(): T | null {
    // 1.没有元素或者一个元素, 直接返回null
    if (this.size === 0) return null
    if (this.size === 1) {
      this.size--
      return this.data.pop()!
    }

    // 2.获取到要删除的元素
    const max = this.data[0]
    // 将最后一个位置的元素, 放到第一个为止
    this.data[0] = this.data.pop()!
    this.size--
    this.heapify_down(0)

    return max
  }

  private heapify_down(index: number) {
    while (2 * index + 1 < this.size) {
      let leftChildIndex = 2 * index + 1
      let rightChildIndex = 2 * index + 2
      // 找到较大的索引
      let largerIndex = leftChildIndex
      if (rightChildIndex < this.size && this.data[rightChildIndex] > this.data[leftChildIndex]) {
        largerIndex = rightChildIndex
      }

      if (this.data[index] >= this.data[largerIndex]) {
        break
      }
      this.swap(index, largerIndex)
      index = largerIndex
    }
  }

  build_heap(arr: T[]) {
    this.data = arr
    this.size = arr.length
    let start = Math.floor((this.size - 1) / 2)
    for (let i = start; i >= 0; i--) {
      this.heapify_down(i)
    }
  }
}

const arr = [19, 100, 36, 17, 3, 25, 1, 2, 7]
// const heap = new Heap<number>()
// for (const item of arr) {
//   heap.insert(item)
// }
// heap.traverse()

// heap.insert(120)
// heap.traverse()

// heap.delete()
// heap.traverse()
// heap.delete()
// heap.traverse()

// heap.build_heap(arr)
// const heap = new Heap(arr)
// console.log(arr)

export {}
