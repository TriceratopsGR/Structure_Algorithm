import { testSort } from './utils'
import { measureSort } from 'hy-algokit'

export default function mergeSort(arr: number[]): number[] {
  if (arr.length <= 1) return arr

  // 将需要排序的数组拆分成多个子数组, 分别对这些子数组进行归并排序(divide)
  // 1.计算中间位置
  const mid = Math.floor(arr.length / 2);
  const leftArr = arr.slice(0, mid)
  const rightArr = arr.slice(mid)

  // 2.对每个子数组进行归并排序
  // 左边数组排好序
  const sortedLeftArr = mergeSort(leftArr)
  // 右边数组排好序
  const sortedRightArr = mergeSort(rightArr)

  // 将排好序的数组进行合并操作(merge)
  // 1.比较左右哪一个更小, 那么先放哪一个位置的元素
  const result: number[] = []
  let i = 0 // 左边子数组的指针
  let j = 0 // 右边子数组的指针
  while (i < sortedLeftArr.length && j < sortedRightArr.length) {
    if (sortedLeftArr[i] <= sortedRightArr[j]) {
      result.push(sortedLeftArr[i])
      i++
    } else {
      result.push(sortedRightArr[j])
      j++
    }
  }

  // 2.考虑到左边或者右边还有剩余, 直接加入到数组中
  // 左边还有剩余
  if (i < sortedLeftArr.length) {
    result.push(...sortedLeftArr.slice(i))
  }
  if (j < sortedRightArr.length) {
    result.push(...sortedRightArr.slice(j))
  }
  // console.log(result)
  return result
}

function mergeSort2(arr: number[]): number[] {
  const n = arr.length;
  mergeSortInternal(arr, 0, n - 1);
  return arr
}

// 归并排序的内部实现函数，对数组 arr 的 [left, right] 区间进行排序
function mergeSortInternal(arr: number[], left: number, right: number): void {
  if (left >= right) {
    // 如果区间只有一个元素或者为空，直接返回
    return;
  }

  const mid = left + Math.floor((right - left) / 2);
  // 递归对左右两个子区间进行排序
  mergeSortInternal(arr, left, mid);
  mergeSortInternal(arr, mid + 1, right);
  // 将排好序的左右两个子区间进行合并
  merge(arr, left, mid, right);
}

// 将已排好序的左右两个子区间合并成一个有序的区间
function merge(arr: number[], left: number, mid: number, right: number): void {
  const temp = new Array(right - left + 1); // 用一个临时数组存放合并结果
  let i = left, j = mid + 1, k = 0;

  // 比较左右两个子区间的元素，将较小的元素插入到 temp 中
  while (i <= mid && j <= right) {
    if (arr[i] <= arr[j]) {
      temp[k++] = arr[i++];
    } else {
      temp[k++] = arr[j++];
    }
  }

  // 如果左子区间还有元素，将它们全部复制到 temp 中
  while (i <= mid) {
    temp[k++] = arr[i++];
  }

  // 如果右子区间还有元素，将它们全部复制到 temp 中
  while (j <= right) {
    temp[k++] = arr[j++];
  }

  // 将 temp 中的元素复制回原数组中
  for (let p = 0; p < temp.length; p++) {
    arr[left + p] = temp[p];
  }
}


// testSort(mergeSort2)
// measureSort(mergeSort2)
