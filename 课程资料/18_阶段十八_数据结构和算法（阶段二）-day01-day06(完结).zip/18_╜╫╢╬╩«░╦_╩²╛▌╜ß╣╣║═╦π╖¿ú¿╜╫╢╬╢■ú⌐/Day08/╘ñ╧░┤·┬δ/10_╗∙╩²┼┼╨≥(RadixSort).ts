import { testSort } from './utils'

function radixSort(array: number[]): number[] {
  if (array.length <= 1) {
    return array;
  }

  // 找到最大值，确定排序的轮数
  const max = Math.max(...array);
  const times = Math.floor(Math.log10(max)) + 1;

  // 桶数组
  const buckets: number[][] = new Array(10).fill(null).map(() => []);

  // 排序轮数
  for (let i = 0; i < times; i++) {
    // 将每个数字按位数放入桶中
    for (let j = 0; j < array.length; j++) {
      const digit = Math.floor(array[j] / Math.pow(10, i)) % 10;
      buckets[digit].push(array[j]);
    }

    // 将桶中的数字按顺序放回原数组
    let index = 0;
    for (let k = 0; k < buckets.length; k++) {
      const bucket = buckets[k];
      for (let l = 0; l < bucket.length; l++) {
        array[index++] = bucket[l];
      }
      buckets[k] = [];
    }
  }

  return array;
}


// testSort(radixSort)

