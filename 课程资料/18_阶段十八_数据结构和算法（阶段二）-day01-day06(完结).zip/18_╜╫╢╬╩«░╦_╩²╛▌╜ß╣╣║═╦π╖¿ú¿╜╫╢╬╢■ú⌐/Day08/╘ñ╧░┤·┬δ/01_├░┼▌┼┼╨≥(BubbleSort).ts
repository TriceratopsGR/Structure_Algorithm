import { swap, testSort } from "./utils"
import { measureSort } from 'hy-algokit'

export default function bubbleSort(arr: number[]): number[] {
  // 1.获取数组的长度
  const length = arr.length

  // 2.外层循环
  for (let i = 0; i < length; i++) {
    // 3.内层循环, 比较相邻两个元素, 将较大值交换到右侧
    for (let j = 0; j < length - 1 - i; j++) {
      if (arr[j] > arr[j + 1]) {
        swap(arr, j, j+  1)
      }
    }
  }

  return arr
}

function bubbleSort2(arr: number[]): number[] {
  // 1.获取数组的长度
  const length = arr.length

  // 2.外层循环
  for (let i = 0; i < length; i++) {
    let swapped = false
    // 3.内层循环, 比较相邻两个元素, 将较大值交换到右侧
    for (let j = 0; j < length - 1 - i; j++) {
      if (arr[j] > arr[j + 1]) {
        swap(arr, j, j+  1)
        swapped = true
      }
    }
    if (!swapped) break
  }

  return arr
}

// testSort(bubbleSort)
// measureSort(bubbleSort2)

