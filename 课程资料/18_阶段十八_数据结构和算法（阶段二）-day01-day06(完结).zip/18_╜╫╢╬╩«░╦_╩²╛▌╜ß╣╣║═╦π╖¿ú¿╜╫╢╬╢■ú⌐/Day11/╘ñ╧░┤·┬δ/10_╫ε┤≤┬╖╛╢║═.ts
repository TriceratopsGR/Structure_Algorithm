import { TreeNode } from "./Node";

function maxPathSum(root: TreeNode | null): number {
  let maxSum = -Infinity

  function dfs(node: TreeNode | null): number {
    if (!node) return 0

    // 左边提供的最大值
    const leftSum = Math.max(dfs(node.left), 0)
    const rightSum = Math.max(dfs(node.right), 0)

    const pathSum = node.val + leftSum + rightSum
    maxSum = Math.max(maxSum, pathSum)

    return node.val + Math.max(leftSum, rightSum)
  }
  dfs(root)

  return maxSum
}