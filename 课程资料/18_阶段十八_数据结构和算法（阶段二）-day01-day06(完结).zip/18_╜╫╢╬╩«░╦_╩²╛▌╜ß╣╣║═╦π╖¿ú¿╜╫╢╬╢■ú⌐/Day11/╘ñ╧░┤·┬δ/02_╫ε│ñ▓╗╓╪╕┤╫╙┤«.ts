function lengthOfLongestSubstring(s: string): number {
  // 1.获取长度
  const n = s.length

  // 2.创建map, 记录每个字符对应的索引
  const map = new Map<string, number>()
  let left = 0
  let max = 0
  for (let right = 0; right < n; right++) {
    const rightChar = s[right]
    if (map.has(rightChar) && map.get(rightChar)! >= left) {
      left = map.get(rightChar)! + 1
    }
    map.set(rightChar, right)
    max = Math.max(max, right - left + 1)
  }

  return max
}