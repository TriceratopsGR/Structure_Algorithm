function fibonacci(n: number, memo: number[] = []): number {
  if (n <= 1) {
    return n;
  }
  if (memo[n] != null) {
    return memo[n];
  }
  const result = fibonacci(n - 1, memo) + fibonacci(n - 2, memo);
  memo[n] = result;
  return result;
}

export {}