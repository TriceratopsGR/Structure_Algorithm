function maxProfit(prices: number[]): number {
  // 1.获取数组的长度
  const n = prices.length
  if (n < 2) return 0

  // 2.定义数组, 保存每个位置的最大值
  let preValue = 0
  let minPrice = prices[0] // 记录最小值
  for (let i = 1; i < n; i++) {
    // 比较昨天的最大利润和今天卖出的最大利润
    preValue = Math.max(preValue, prices[i] - minPrice)
    minPrice = Math.min(prices[i], minPrice)
  }

  return preValue
}

export {}
