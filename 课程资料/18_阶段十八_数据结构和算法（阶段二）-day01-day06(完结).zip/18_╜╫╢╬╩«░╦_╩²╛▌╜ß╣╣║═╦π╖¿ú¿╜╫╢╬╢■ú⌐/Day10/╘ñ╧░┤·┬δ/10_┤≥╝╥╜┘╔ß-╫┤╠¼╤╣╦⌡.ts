function rob(nums: number[]): number {
  const n = nums.length
  if (n === 0) return 0
  if (n === 1) return nums[0]

  // 初始化dp状态数组
  let pre = 0
  let cur = nums[0]

  for (let i = 2; i <= n ; i++) {
    const temp = cur
    cur = Math.max(pre + nums[i - 1], cur)
    pre = temp
  }

  return cur
}

export {}
